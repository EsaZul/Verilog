Lab_3 contains part 2 of the lab. The sprinkler with constraints.

Lab3_SW contains the Seven-Segment Display